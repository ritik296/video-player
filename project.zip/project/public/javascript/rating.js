function getRating(rating){
    alert(`You gave ${rating} to this course`);
}