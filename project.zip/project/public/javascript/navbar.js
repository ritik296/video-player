const menuButton = document.getElementById('menu-btn');
const mobileMenu = document.getElementById('mobile-menu');

menuButton.addEventListener('click', () => {
  mobileMenu.classList.toggle('hidden');
});

// Sign in button functionality
const signInButton = document.getElementById('signin-btn');
const mobileSignInButton = document.getElementById('mobile-signin-btn');

signInButton.addEventListener('click', () => {
  alert('Sign in clicked!');
});

mobileSignInButton.addEventListener('click', () => {
  alert('Sign in clicked!');
});