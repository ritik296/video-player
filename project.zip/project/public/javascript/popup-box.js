function closePopupBox(){
    popupBox.classList.add('hidden');
    shareBox.classList.add('hidden');
    ratingBox.classList.add('hidden');
}